//
//  GameScene.swift
//  fading bubbles
//
//  Created by student on 2019/5/9.
//  Copyright © 2019年 student. All rights reserved.
//

import SpriteKit
import GameplayKit
import AVFoundation

var scoreNumber = 0


class GameScene: SKScene {
    
    
    let scoreLabel = SKLabelNode(fontNamed: "Pusab")//設定字體型式
    
    let playCorrectSound = SKAction.playSoundFileNamed("Correct.wav", waitForCompletion: false)
    let playGameOverSound = SKAction.playSoundFileNamed("GameOverSound.wav", waitForCompletion: false)
    
    let gameArea :CGRect
    
    override init(size: CGSize) {
        
        let maxAspectRatio : CGFloat = 16.0/9.0
        let playableWidth = size.height / maxAspectRatio
        let gameAreaMargin = (size.width-playableWidth)/2
        gameArea = CGRect(x:gameAreaMargin,y : 0 , width : playableWidth,height: size.height)
        
        super.init(size: size)
    }
    	
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func random() -> CGFloat{
        return CGFloat(Float(arc4random())/0xFFFFFFFF)
    }
    
    func random(min :CGFloat,max: CGFloat)-> CGFloat{
        return random() * (max - min) + min
    }
    
    override func didMove(to view: SKView) {
        
        scoreNumber = 0
        playSound()
        
        let background =  SKSpriteNode(imageNamed: "BubbleBackgroud")
        background.size = self.size
        background.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
        background.zPosition = 0
        self.addChild(background)
        
        let bubble = SKSpriteNode(imageNamed: "Bubble2")
        bubble.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
        bubble.zPosition = 2
        bubble.name="BubbleObject"
        self.addChild(bubble)
        
        scoreLabel.fontSize = 250
        scoreLabel.text = "0"
        scoreLabel.fontColor = #colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1)
        scoreLabel.zPosition = 1
        scoreLabel.position = CGPoint (x: self.size.width/2, y:self.size.height*0.85)
        self.addChild(scoreLabel)
    
    }
    
    func spawnNewBubble(){ //產生子Bubble
        
        var randomImageNumber = arc4random()%4
        randomImageNumber += 1
        
        let bubble = SKSpriteNode(imageNamed: "Bubble\(randomImageNumber)")
        bubble.zPosition = 2
        bubble.name="BubbleObject"

        let randomX = random(min: gameArea.minX+bubble.size.width/2,
                             max: gameArea.maxX-bubble.size.width/2)
        
        let randomY = random(min: gameArea.minY+bubble.size.width/2,
                             max: gameArea.maxY-bubble.size.width/2)
        
        bubble.position = CGPoint(x: randomX,y: randomY)
        self.addChild(bubble)
        
        bubble.run(SKAction.sequence([
            SKAction.scale(to: 0, duration: 3),
            playGameOverSound,
            
            SKAction.run(runGameOver)
            
            ]))
    }
    
    func runGameOver(){
        audioPlayer.stop()
        let sceneToMoveTo = GameOverScene(size: self.size)
        sceneToMoveTo.scaleMode = self.scaleMode
        let sceneTransition = SKTransition.fade(withDuration: 0.2)
        self.view!.presentScene(sceneToMoveTo, transition: sceneTransition)
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch: AnyObject in  touches
        {
      
            let positionOfTouch = touch.location(in: self)
            let tappedNode = atPoint(positionOfTouch)
            let nameOfTappedNode = tappedNode.name
            
            
            if  nameOfTappedNode == "BubbleObject"
            {
                tappedNode.name = ""
                tappedNode.removeAllActions()
                
                tappedNode.run(SKAction.sequence([SKAction.fadeOut(withDuration: 0.1),SKAction.removeFromParent()]))
            
                self.run(playCorrectSound)
                tappedNode.removeFromParent()
                spawnNewBubble()
                
                scoreNumber += 1
                scoreLabel.text = String(scoreNumber)
                //scoreLabel.text = "\n(scoreNumber)"
                
                if scoreNumber == 10 || scoreNumber == 30 || scoreNumber == 50 || scoreNumber == 70 || scoreNumber == 90 || scoreNumber == 110{
                    spawnNewBubble()  //當分數達到上面規定的時候增加他的Bubbleg數量
                }
            }
        
        }
    }
    func playSound(){
        let path = Bundle.main.path(forResource: soundfileName, ofType: "mp3")//設定播放路徑
        let soundUrl = URL(fileURLWithPath: path!)//轉換成url
        
        do {
            try audioPlayer = AVAudioPlayer(contentsOf: soundUrl)//加載音樂
            audioPlayer.volume = 1.0
            audioPlayer.numberOfLoops = -1 //無限循環
            audioPlayer.play()
        }catch{
            print("error")
        }
  
    }
    
}
