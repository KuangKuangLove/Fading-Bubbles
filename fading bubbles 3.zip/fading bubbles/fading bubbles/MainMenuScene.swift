//
//  MainMenuScene.swift
//  fading bubbles
//
//  Created by student on 2019/5/9.
//  Copyright © 2019年 student. All rights reserved.
//

import Foundation
import SpriteKit
import AVFoundation  //導入音頻模組

var audioPlayer:AVAudioPlayer = AVAudioPlayer()//初始化
class MainMenuScene: SKScene{
    
    let clickSoundEffect = SKAction.playSoundFileNamed("Click.wav", waitForCompletion: false)
    
    override func didMove(to view: SKView){
    do{ 
            let path = Bundle.main.path(forResource: "aaa", ofType: "mp3")//設定播放路徑
            let soundUrl = URL(fileURLWithPath: path!)//轉換成url
            try audioPlayer = AVAudioPlayer(contentsOf: soundUrl)//加載音樂
            audioPlayer.volume = 1.0
            audioPlayer.numberOfLoops = -1 //無限循環
            audioPlayer.play()
    }catch{
            print("error")
    }
    
    let background = SKSpriteNode(imageNamed: "BubbleBackgroud")
    background.size = self.size
    background.zPosition = 0
    background.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
    self.addChild(background)
    
    let gameTitleLabel1 = SKLabelNode(fontNamed: "XHARP")
    gameTitleLabel1.text = "Fading Bubble"
    gameTitleLabel1.fontSize = 85
    gameTitleLabel1.fontColor = SKColor.white
    gameTitleLabel1.position = CGPoint(x: self.size.width/2, y: self.size.height*0.75)
    gameTitleLabel1.zPosition = 1
    self.addChild(gameTitleLabel1)
    
    let gameTitleLabel2 = SKLabelNode(fontNamed: "XHARP")
    gameTitleLabel2.text = "Let play the game"
    gameTitleLabel2.fontSize = 50
    gameTitleLabel2.fontColor = SKColor.white
    gameTitleLabel2.position = CGPoint(x: self.size.width/2, y: self.size.height*0.6)
    gameTitleLabel2.zPosition = 1
    self.addChild(gameTitleLabel2)
    
    let gameByLabel = SKLabelNode(fontNamed: "XHARP")
    gameByLabel.text = "ios Final project"
    gameByLabel.fontColor = SKColor.white
    gameByLabel.fontSize = 50
    gameByLabel.position = CGPoint(x: self.size.width/2, y: self.size.height*0.08)
    gameByLabel.zPosition = 1
    self.addChild(gameByLabel)
        
    let howToPlayLabel = SKLabelNode(fontNamed: "XHARP")
    howToPlayLabel.text = "Tap The Disc Before They Vamish"
    howToPlayLabel.fontSize = 30
    howToPlayLabel.fontColor = SKColor.white
    howToPlayLabel.position = CGPoint(x: self.size.width/2, y: self.size.height*0.04)
    howToPlayLabel.zPosition = 1
    self.addChild(howToPlayLabel)
        
    let startLabel = SKLabelNode(fontNamed: "XHARP")
    startLabel.text = "Play"
    startLabel.fontSize = 150
    startLabel.fontColor = SKColor.white
    startLabel.position = CGPoint(x: self.size.width/2, y: self.size.height*0.35)
    startLabel.zPosition = 1
    startLabel.name = "startButton"
    self.addChild(startLabel)
    
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch: AnyObject in touches
        {
            
            let pointOnTouch = touch.location(in: self)
            let tappedNode = atPoint(pointOnTouch)
            let tappedNodeName = tappedNode.name
            
            if tappedNodeName == "startButton"{
                self.run(clickSoundEffect)
                audioPlayer.stop()
                
                let sceneToMoveTo = GameSceneChoose(size: self.size)
                sceneToMoveTo.scaleMode = self.scaleMode
                let sceneTransition = SKTransition.fade(withDuration: 0.2)
                self.view!.presentScene(sceneToMoveTo, transition: sceneTransition)
            
            }
        }
    }
}
