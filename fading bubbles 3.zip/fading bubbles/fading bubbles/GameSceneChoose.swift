//
//  GameSceneChoose.swift
//  fading bubbles
//
//  Created by student on 2019/5/24.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit
import SpriteKit
import AVFoundation

var soundfileName : String = " "

var soundArr : [String]=["Sound1","Sound2","Sound3","Sound4","Sound5"]//陣列存放音檔檔名
var index : Int = 0

class GameSceneChoose: SKScene {
    
//    var audioPlayer : AVAudioPlayer?
    var audioPlayer:AVAudioPlayer = AVAudioPlayer()
    
 
    
    override func didMove(to view: SKView) {
        
        let background = SKSpriteNode(imageNamed: "BubbleBackgroud")
        background.size = self.size
        background.zPosition = 0
        background.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
        self.addChild(background)
        
        let sound1 = SKSpriteNode(imageNamed: "撩一下") //設置第一首歌的點擊位置
        sound1.position = CGPoint(x: self.size.width/2, y: self.size.height*0.7)
        sound1.zPosition = 1
        sound1.size = CGSize(width: 960, height: 360)
        sound1.name = "Sound1Object"
        self.addChild(sound1)
        
        let sound2 = SKSpriteNode(imageNamed: "37˚") //設置第二首歌的點擊位置
        sound2.position = CGPoint(x: self.size.width/2, y: self.size.height*0.5)
        sound2.zPosition = 1
        sound2.size = CGSize(width: 960, height: 360)
        sound2.name = "Sound2Object"
        self.addChild(sound2)
        
        let sound3 = SKSpriteNode(imageNamed: "小胖子") //設置第三首歌的點擊位置
        sound3.position = CGPoint(x: self.size.width/2, y: self.size.height*0.3)
        sound3.zPosition = 1
        sound3.size = CGSize(width: 960, height: 360)
        sound3.name = "Sound3Object"
        self.addChild(sound3)
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch: AnyObject in touches //點擊到的時候發生的事件
        {
            
            let pointOnTouch = touch.location(in: self)
            let tappedNode = atPoint(pointOnTouch)
            let tappedNodeName = tappedNode.name
        
            
            if tappedNodeName == "Sound1Object"{ // 第一首歌
                
                soundfileName = soundArr[0]
                let sceneToMoveTo = GameScene(size: self.size)
                sceneToMoveTo.scaleMode = self.scaleMode
                let sceneTransition = SKTransition.fade(withDuration: 0.2)
                self.view!.presentScene(sceneToMoveTo, transition: sceneTransition)
                
            }
            else if tappedNodeName == "Sound2Object"{//第二首歌
                
                
                soundfileName = soundArr[1]
                let sceneToMoveTo = GameScene(size: self.size)
                sceneToMoveTo.scaleMode = self.scaleMode
                let sceneTransition = SKTransition.fade(withDuration: 0.2)
                self.view!.presentScene(sceneToMoveTo, transition: sceneTransition)
                
            }
            else if tappedNodeName == "Sound3Object"{ //第三首歌
                
                soundfileName = soundArr[2]
                let sceneToMoveTo = GameScene(size: self.size)
                sceneToMoveTo.scaleMode = self.scaleMode
                let sceneTransition = SKTransition.fade(withDuration: 0.2)
                self.view!.presentScene(sceneToMoveTo, transition: sceneTransition)
                
            }
                
        }
    }
    
}
